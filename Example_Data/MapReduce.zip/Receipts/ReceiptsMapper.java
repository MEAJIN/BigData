package Receipts;

import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.LongWritable;
import java.io.IOException;
import java.util.StringTokenizer;

public class ReceiptsMapper extends Mapper <LongWritable, Text, Text, Text>{
	private final Text tempText = new Text();
	public void map(LongWritable key, Text value, Context context) throws IOException,
	       InterruptedException{
		       StringTokenizer iterator = new StringTokenizer(value.toString()," ");

		       String year = new String(iterator.nextToken()).toString();

		       iterator.nextToken();
		       iterator.nextToken();
		       tempText.set(iterator.nextToken());
		       context.write(new Text("summary"), new Text(year+"_"+tempText.toString()));
	}
}
