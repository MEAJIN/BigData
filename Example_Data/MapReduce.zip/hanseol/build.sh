#!/bin/bash

export HADOOP_HOME=/home/bigdata/hadoop-2.7.7
export CLASSPATH=$HADOOP_HOME/share/hadoop/mapreduce/*:$HADOOP_HOME/share/hadoop/mapreduce/lib*:$HADOOP_HOME/share/hadoop/common/lib/*:$HADOOP_HOME/share/hadoop/common/*:$HADOOP_HOME/share/hadoop/tools/lib/*:$HADOOP_HOME/share/hadoop/yarn/*:$HADOOP_HOME/share/hadoop/yarn/lib/*

export HADOOP_CLASSPATH=$CLASSPATH

javac -d classes/ LogIpMapper.java
javac -d classes/ LogIpReducer.java
jar -cvf LogIp.jar -C classes/ .
javac -classpath $CLASSPATH:LogIp.jar -d classes/ LogIpJob.java
jar -uvf LogIp.jar -C classes/ .
