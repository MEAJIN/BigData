import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

public class LogIpMapper extends Mapper<LongWritable, Text, Text,IntWritable>{
	private static String[] Impo;
	public void map(LongWritable key, Text input, Context context){
		try{
			String line = input.toString();
			Impo = line.split(" ");
			String ip = Impo[0];

			context.write(new Text(ip), new IntWritable(1));
			
		}catch(IOException e){
			e.printStackTrace();
		}catch(InterruptedException e){
			e.printStackTrace();
		}
	}
}
